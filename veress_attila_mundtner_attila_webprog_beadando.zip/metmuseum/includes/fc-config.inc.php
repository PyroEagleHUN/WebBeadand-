<?php
$oldalak = array(
	'main' => array('fajl' => 'main', 'szoveg' => 'Main'),
	'gallery' => array('fajl' => 'gallery', 'szoveg' => 'Gallery'),
	'contact' => array('fajl' => 'contact', 'szoveg' => 'Contact'),
	'exhibitions' => array('fajl' => 'exhibitions', 'szoveg' => 'Exhibitions'),
    'videos' => array('fajl' => 'videos', 'szoveg' => 'Videos'),
	'feltolt' => array('fajl' => 'feltolt', 'szoveg' => 'Feltolt'),
	'regisztracio' => array('fajl' => 'regisztracio', 'szoveg' => 'regisztracio')
);

$hiba_oldal = array ('fajl' => '404', 'szoveg' => 'A keresett oldal nem található!');
?>
