<?php
 $MAPPA = './kepek/'; // './kepek/' is jó
 $TIPUSOK = array ('.jpg', '.png'); // kép típusok
 $MEDIATIPUSOK = array('image/jpeg', 'image/png');
 $DATUMFORMA = "Y.m.d. H:i";
// Dátum kiíratásnál felhasználjuk
// Ilyen alakban írja ki: 2016.10.22. 08:33 lásd az ábrát
// https://www.w3schools.com/php/func_date_date.asp
 $MAXMERET = 500*1024; // Majd a 2-es feladatban használjuk fel *:szorzás
?>