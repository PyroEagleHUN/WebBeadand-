 <!DOCTYPE html>
<html>
<head>
<title>Met Museum</title>
</head>
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>

<div class="sidenav">
  <a href="index.php?oldal=main">About</a>
  <a href="index.php?oldal=videos">Videos</a>
  <a href="index.php?oldal=exhibitions">Current Exhibitions</a>
  <a href="index.php?oldal=contact">Contact</a>
  <a href="index.php?oldal=gallery">Gallery</a>
  <a href="index.php?oldal=regisztracio">Belépés</a>
</div>

<div class="main">
  <h2>Contact</h2>
  
  <footer class="global-footer">
    <div class="global-footer__wrapper">
        <div class="global-footer__primary">
            <div class="global-footer__locations">
                <ul class="global-footer__locations-items">
        

                            <li class="global-footer__locations-item"><div class="museum-address">
<div class="museum-address__name"><span class="notranslate">The Met Fifth Avenue</span></div>
<address class="museum-address__information">
<ul class="museum-address__information-items">
    <li class="museum-address__information-item">1000 Fifth Avenue</li>
    <li class="museum-address__information-item">New York, NY 10028</li>
    <li class="museum-address__information-item">Phone: 212-535-7710</li>
</ul>
</address>
</div></li>
                            <li class="global-footer__locations-item"><div class="museum-address">
<div class="museum-address__name"><span class="notranslate">The Met Breuer</span></div>
<address class="museum-address__information">
<ul class="museum-address__information-items">
    <li class="museum-address__information-item">945 Madison Avenue</li>
    <li class="museum-address__information-item">New York, NY 10021</li>
    <li class="museum-address__information-item">Phone: 212-731-1675</li>
</ul>
</address>
</div></li>
                            <li class="global-footer__locations-item"><div class="museum-address">
<div class="museum-address__name"><span class="notranslate">The Met Cloisters</span></div>
<address class="museum-address__information">
<ul class="museum-address__information-items">
    <li class="museum-address__information-item">99 Margaret Corbin Drive</li>
    <li class="museum-address__information-item">Fort Tryon Park</li>
    <li class="museum-address__information-item">New York, NY 10040</li>
    <li class="museum-address__information-item">Phone: 212-923-3700</li>
</ul>
</address>
</div></li>
                </ul>
            </div>
        </div>
        
        <div class="global-footer__secondary">
            <div class="global-footer__secondary-wrapper">
                <form
	name="footerNewsletter"
	class="global-footer__newsletter-signup form__field-wrapper inline">
		<div class="js-global-footer__newsletter-wrapper">
    	
        
       
                </ul>
            </nav>
        </div>
    </div>
</footer>
  
</div>
</body>
</html>