<head>
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body style='margin-left:185px;'>

<?php include('./pages/menu.php');?>
<?php
session_start();

$userinfo = array(
                'user1'=>'password1',
                'user2'=>'password2'
                );

if(isset($_GET['logout'])) {
    $_SESSION['username'] = '';
    header('Location:  ' . $_SERVER['PHP_SELF']);
}

if(isset($_POST['username'])) {
    if($userinfo[$_POST['username']] == $_POST['password']) {
		$_SESSION['username'] = $_POST['username'];
		echo 'sikeres belépés';
    }else {
		echo 'sikertelen belépés';
        //Invalid Login
    }
}
?>

	<div id="wrapper">
		<div id="login" class="animate form">
			<form autocomplete="on"> 
				<h1>Bejelentkezés</h1> 
				<p> 
					<label for="username" class="uname" data-icon="u" > Felhasználó név </label>
					<input id="username" name="username" required="required" type="text" placeholder="felhasznalonev"/>
				</p>
				<p> 
					<label for="password" class="youpasswd" data-icon="p"> Jelszó </label>
					<input id="password" name="password" required="required" type="password" placeholder="pl.: X8df!90EO" /> 
				</p>
				<p class="login button"> 
					<input type="submit" name="submit" value="Submit" />
				</p>
				<p class="change_link">
					Nem vagy még tag ?
					<a href="#toregister" class="to_register">Csatlakozz</a>
				</p>
			</form>
		</div>

		<div id="register" class="animate form">
			
				<h1> Regisztrálás </h1> 
				<p> 
					<label for="usernamesignup" class="uname" data-icon="u">Felhasználó név</label>
					<input id="usernamesignup" name="usernamesignup" required="required" type="text" placeholder="felhasznalonev" />
				</p>
				<p> 
					<label for="emailsignup" class="youmail" data-icon="e" > E-mail</label>
					<input id="emailsignup" name="emailsignup" required="required" type="email" placeholder="email.cimem@szolgaltato.az"/> 
				</p>
				<p> 
					<label for="passwordsignup" class="youpasswd" data-icon="p">Jelszó </label>
					<input id="passwordsignup" name="passwordsignup" required="required" type="password" placeholder="pl.: X8df!90EO"/>
				</p>
				<p> 
					<label for="passwordsignup_confirm" class="youpasswd" data-icon="p">Jelszó megerősítése </label>
					<input id="passwordsignup_confirm" name="passwordsignup_confirm" required="required" type="password" placeholder="pl.: X8df!90EO"/>
				</p>
				<p class="signin button"> 
					<input type="submit" value="Regisztráció"/> 
				</p>
				<p class="change_link">  
					Már tag vagy ?
					<a href="#tologin" class="to_register"> Menj és lépjbe </a>
				</p>
		
		</div>
		
	</div>
  
</body>