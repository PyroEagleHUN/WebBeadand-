 <!DOCTYPE html>
<html>
<head>
<title>Met Museum</title>
</head>
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>

<?php include('./pages/menu.php');?>

<div class="main">
  <h2>Current Exhibitions</h2>
  
    <footer class="global-footer">
    <div class="global-footer__wrapper">
        <div class="global-footer__primary">
            <div class="global-footer__locations">
                <ul class="global-footer__locations-items">
        

                            <li class="global-footer__locations-item"><div class="museum-address">
<div class="museum-address__name"><span class="notranslate">The Met Fifth Avenue</span></div>
<address class="museum-address__information">
<ul class="museum-address__information-items">
    <li class="museum-address__information-item">The First Knight</li>
    <li class="museum-address__information-item">Vija Celmins</li>
    <li class="museum-address__information-item">Felix Vallotton</li>
    <li class="museum-address__information-item">Making Marvels</li>
    <li class="museum-address__information-item">In Praise of Painting</li>
</ul>
</address>
</div></li>
                            <li class="global-footer__locations-item"><div class="museum-address">
<div class="museum-address__name"><span class="notranslate">The Met Breuer</span></div>
<address class="museum-address__information">
<ul class="museum-address__information-items">
    <li class="museum-address__information-item">Epic Abstractions</li>
    <li class="museum-address__information-item">Art of native america</li>
    <li class="museum-address__information-item">Home is a foreign place</li>
</ul>
</address>
</div></li>
                            <li class="global-footer__locations-item"><div class="museum-address">
<div class="museum-address__name"><span class="notranslate">The Met Cloisters</span></div>
<address class="museum-address__information">
<ul class="museum-address__information-items">
    <li class="museum-address__information-item">The Colmar Treasure</li>
    <li class="museum-address__information-item">Rayyanae Tabet Alien Property</li>
    <li class="museum-address__information-item">Kyoto</li>
    <li class="museum-address__information-item">The Renesaissance of Etching</li>
</ul>
</address>
</div></li>
                </ul>
            </div>
        </div>
        
        <div class="global-footer__secondary">
            <div class="global-footer__secondary-wrapper">
                <form
	name="footerNewsletter"
	class="global-footer__newsletter-signup form__field-wrapper inline">
		<div class="js-global-footer__newsletter-wrapper">
    	
        
       
                </ul>
        </div>
    </div>
    <h2>Videos</h2>
  
  <video width="500" height="500" controls>
  <source src="video1.mp4" type="video/mp4">
Your browser does not support the video tag.
</video> 

<iframe width="560" height="315" src="https://www.youtube.com/embed/MKikHxKeodA"></iframe>
</footer>
  
</div>
</body>
</html>