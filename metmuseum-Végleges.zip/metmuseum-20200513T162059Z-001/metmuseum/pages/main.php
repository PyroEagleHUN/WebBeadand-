 <!DOCTYPE html>
<html>
<head>
<title>Met Museum</title>
</head>
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 160px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>

<?php include('./pages/menu.php');?>

<div class="main">
<img width="1300" height="600" class="image-style-banner-image-1920x480" src="kep1.png" alt="" />
  <h2>About</h2>
  Elérhetőség: <a href="https://www.metmuseum.org/">Metmuseum főoldala</a>
  
  <p>The Met presents over 5,000 years of art from around the world for everyone to experience and enjoy. The Museum lives in three iconic sites in New York City—The Met Fifth Avenue, The Met Breuer, and The Met Cloisters. Millions of people also take part in The Met experience online.
</p>
  <p>Since it was founded in 1870, The Met has always aspired to be more than a treasury of rare and beautiful objects. Every day, art comes alive in the Museum's galleries and through its exhibitions and events, revealing both new ideas and unexpected connections across time and across cultures.</p>
  <h2>Mission Statement</h2>
  <p>The Metropolitan Museum of Art was founded on April 13, 1870, "to be located in the City of New York, for the purpose of establishing and maintaining in said city a Museum and library of art, of encouraging and developing the study of the fine arts, and the application of arts to manufacture and practical life, of advancing the general knowledge of kindred subjects, and, to that end, of furnishing popular instruction."</p>
  <p>This statement of purpose has guided the Museum for over 140 years.</p>
  <p>On January 13, 2015, the Trustees of The Metropolitan Museum of Art reaffirmed this statement of purpose and supplemented it with the following statement of mission:</p>
  <p>The Metropolitan Museum of Art collects, studies, conserves, and presents significant works of art across all times and cultures in order to connect people to creativity, knowledge, and ideas.</p>
</div>
</body>
</html>